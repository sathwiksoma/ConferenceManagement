﻿using System.ComponentModel.DataAnnotations;

namespace ConferenceManagement.Models
{
    public class UserLogin
    {
        public string Username { get; set; }

        [Required]
        [MaxLength(255)]
        public string Password { get; set; }
    }
}
